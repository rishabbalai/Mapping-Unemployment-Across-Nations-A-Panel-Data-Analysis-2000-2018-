library(readxl)
library(plm)

# Setting the Working Directory
current_path <- rstudioapi::getActiveDocumentContext()$path
setwd(dirname(current_path ))
getwd()

# Load data
df <- read_excel("unemployment_low_income.xlsx", na = "..")

# Remove rows with missing values
df <- na.omit(df)


colnames(df)


numerical_cols <- sapply(df, is.numeric)
numerical_data <- df[, numerical_cols]

# Standardizing numerical variables
standardized_data <- as.data.frame(scale(numerical_data))

# Combining standardized numerical variables with non-numerical variables
non_numerical_data <- df[, !numerical_cols]
df <- cbind(non_numerical_data, standardized_data)


str(df)



# Sort data by Country and Time
df <- df[order(df$Country, df$Time),]



# Pooled model 
pooled <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
            model = "pooling")

summary(pooled)


#2way fixed effect



lsdv <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
              model = "within",  effect= "twoways")

summary(lsdv)
summary(fixef(lsdv, effect = 'time'))
summary(fixef(lsdv, effect = 'individual'))


#F-test

pFtest(lsdv, pooled)




# Random Effects Model
re_model <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
              model = "random", effect= "twoways")
summary(re_model)

ercomp <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
              method = "swar", effect= "twoways")
summary(ercomp)


#First difference


fd_model <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
                model = "fd")
summary(fd_model)

library(car)

vif_pooled <- vif(pooled)

vif_pooled











#high income


library(readxl)
library(plm)

# Load data
df <- read_excel("C:\\Desktop\\final project\\unemployment_high_income.xlsx", na = "..")

# Remove rows with missing values
df <- na.omit(df)


colnames(df)


numerical_cols <- sapply(df, is.numeric)
numerical_data <- df[, numerical_cols]

# Standardizing numerical variables
standardized_data <- as.data.frame(scale(numerical_data))

# Combining standardized numerical variables with non-numerical variables
non_numerical_data <- df[, !numerical_cols]
df <- cbind(non_numerical_data, standardized_data)


str(df)



# Sort data by Country and Time
df <- df[order(df$Country, df$Time),]



# Pooled model 
pooled <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
              model = "pooling")

summary(pooled)


#2way fixed effect

lsdv <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
            model = "within", effect= "twoways")
summary(lsdv)

summary(lsdv)
summary(fixef(lsdv, effect = 'time'))
summary(fixef(lsdv, effect = 'individual'))


#F-test

pFtest(lsdv, pooled)




# Random Effects Model
re_model <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
                model = "random", effect= "twoways")
summary(re_model)

ercomp <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
              method = "swar", effect= "twoways")
summary(ercomp)


#First difference


fd_model <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
                model = "fd")
summary(fd_model)


library(car)

vif_pooled <- vif(pooled)

vif_pooled




#low middle income 


library(readxl)
library(plm)

# Load data
df <- read_excel("C:\\Desktop\\final project\\umemployment final_lower_middle.xlsx", na = "..")

# Remove rows with missing values
df <- na.omit(df)


colnames(df)


numerical_cols <- sapply(df, is.numeric)
numerical_data <- df[, numerical_cols]

# Standardizing numerical variables
standardized_data <- as.data.frame(scale(numerical_data))

# Combining standardized numerical variables with non-numerical variables
non_numerical_data <- df[, !numerical_cols]
df <- cbind(non_numerical_data, standardized_data)


str(df)



# Sort data by Country and Time
df <- df[order(df$Country, df$Time),]



# Pooled model 
pooled <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
              model = "pooling")

summary(pooled)


#2way fixed effect

lsdv <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
            model = "within", effect= "twoways")
summary(lsdv)

summary(lsdv)
summary(fixef(lsdv, effect = 'time'))
summary(fixef(lsdv, effect = 'individual'))


#F-test

pFtest(lsdv, pooled)




# Random Effects Model
re_model <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
                model = "random", effect= "twoways")
summary(re_model)

ercomp <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
              method = "swar", effect= "twoways")
summary(ercomp)


#First difference


fd_model <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
                model = "fd")
summary(fd_model)







#upper middle income




library(readxl)
library(plm)

# Load data
df <- read_excel("C:\\Desktop\\final project\\unemployment_upper_middle.xlsx", na = "..")

# Remove rows with missing values
df <- na.omit(df)


colnames(df)


numerical_cols <- sapply(df, is.numeric)
numerical_data <- df[, numerical_cols]

# Standardizing numerical variables
standardized_data <- as.data.frame(scale(numerical_data))

# Combining standardized numerical variables with non-numerical variables
non_numerical_data <- df[, !numerical_cols]
df <- cbind(non_numerical_data, standardized_data)


str(df)



# Sort data by Country and Time
df <- df[order(df$Country, df$Time),]



# Pooled model 
pooled <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
              model = "pooling")

summary(pooled)


#2way fixed effect

lsdv <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
            model = "within", effect= "twoways")
summary(lsdv)

summary(lsdv)
summary(fixef(lsdv, effect = 'time'))
summary(fixef(lsdv, effect = 'individual'))


#F-test

pFtest(lsdv, pooled)




# Random Effects Model
re_model <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
                model = "random", effect= "twoways")
summary(re_model)

ercomp <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
              method = "swar", effect= "twoways")
summary(ercomp)


#First difference


fd_model <- plm(df$`Unemployment, total (% of total labor force) (modeled ILO estimate) [SL.UEM.TOTL.ZS]`~df$`Gross fixed capital formation (% of GDP) [NE.GDI.FTOT.ZS]`+df$`GDP growth (annual %) [NY.GDP.MKTP.KD.ZG]`+df$`Inflation, GDP deflator (annual %) [NY.GDP.DEFL.KD.ZG]`+df$`Population growth (annual %) [SP.POP.GROW]`+df$`Compulsory education, duration (years) [SE.COM.DURS]`+df$`Net migration [SM.POP.NETM]`+df$`Urban population growth (annual %) [SP.URB.GROW]`+df$`Rural population (% of total population) [SP.RUR.TOTL.ZS]`+df$`Crop production index (2014-2016 = 100) [AG.PRD.CROP.XD]`, data=df,index = c("Country", "Time"), 
                model = "fd")
summary(fd_model)







