library(readxl)
library(plm)

df = read_excel("C:/Users/gauta/Desktop/ECON322/Group Project/Employment/employment_clean2_worldaggregates.xlsx", na = "..")
str(df)

df <- df[, !(names(df) %in% "secondary_enrollment")]
df <- df[, !(names(df) %in% "inflation_cpi")]
#df <- df[, !(names(df) %in% "gross_fixed_capital_formation")]
#df <- df[, !(names(df) %in% "gdp_growth")]
#df <- df[, !(names(df) %in% "rural_pop")]
#df <- df[, !(names(df) %in% "rural_pop_growth")]
#df <- df[, !(names(df) %in% "urban_pop")]
#df <- df[, !(names(df) %in% "urban_pop_growth")]
df <- df[, !(names(df) %in% "edu_expenditure")]
#df <- df[, !(names(df) %in% "inflation_deflator")]
#df <- df[, !(names(df) %in% "gdp_capita")]
df <- df[, !(names(df) %in% "trade_composition")]


df = na.omit(df)
df <- df[order(df$country, df$time),]
df_2 <- df
numerical_cols <- sapply(df, is.numeric)
numerical_data <- df[, numerical_cols]

# Standardizing numerical variables
standardized_data <- as.data.frame(scale(numerical_data))

# Combining standardized numerical variables with non-numerical variables
non_numerical_data <- df[, !numerical_cols]
df <- cbind(non_numerical_data, standardized_data)
df$time <- df_2$time

str(df)



plot(df$unemployment, df$inflation)
plot(df$unemployment, df$gross_fixed_capital_formation)
plot(df$unemployment, df$gdp_growth)
plot(df$unemployment, df$rural_pop)
plot(df$unemployment, df$rural_pop_growth)
plot(df$unemployment, df$urban_pop_growth)
plot(df$unemployment, df$comp_edu)
plot(df$unemployment, df$inflation)

plot(density(df$unemployment))
plot(density(df$gross_fixed_capital_formation))
plot(density(df$gdp_growth))
plot(density(df$rural_pop))
plot(density(df$rural_pop_growth))
plot(density(df$urban_pop_growth))
plot(density(df$comp_edu))
plot(density(df$inflation))


plot(density(log(df$unemployment)))
plot(density((df$inflation)))

lsdv_model <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
                    rural_pop + rural_pop_growth + urban_pop_growth + comp_edu + inflation_deflator
                  + gdp_capita + region + income_group,  
                data = df, 
                index = c("country", "time"), 
                model = "within",
                effect = 'twoways')
summary(lsdv_model)
summary(fixef(lsdv_model, effect = 'time'))
summary(fixef(lsdv_model, effect = 'individual'))

# World model
re_model <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
                rural_pop + rural_pop_growth + urban_pop_growth + comp_edu
                + gdp_capita + region + income_group, 
                data = df, 
                index = c("country", "time"), 
                model = "random",
                effect = 'twoways')
summary(re_model)
ercomp(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
         rural_pop + rural_pop_growth + urban_pop_growth
       + gdp_capita + secondary_enrollment + trade_composition + region + income_group,
       data = df, method = "swar", effect = "twoways")

# World model with only sig variables
re_model2 <- plm(unemployment ~ gross_fixed_capital_formation, 
                data = df, 
                index = c("country", "time"), 
                model = "random",
                effect = 'twoways')
summary(re_model2)
ercomp(unemployment ~ gross_fixed_capital_formation + urban_pop_growth,
       data = df, method = "swar", effect = "twoways", index = c('country','time'))



fe_model <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
                  rural_pop + rural_pop_growth + urban_pop_growth + comp_edu + inflation_deflator
                + gdp_capita + region + income_group, 
                data = df, 
                index = c("country", "time"), 
                model = "within")

summary(fe_model)
summary(fixef(fe_model, type ='dmean'))

pooled_model <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
                      rural_pop + rural_pop_growth + urban_pop_growth + comp_edu + inflation_deflator
                    + gdp_capita + region + income_group, 
                data = df, 
                index = c("country", "time"), 
                model = "pooling")
summary(pooled_model)

fd_model <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
                  rural_pop + rural_pop_growth + urban_pop_growth + comp_edu + inflation_deflator
                + gdp_capita + secondary_enrollment + trade_composition + region + income_group,  
                data = df, 
                index = c("country", "time"), 
                model = "fd")

summary(fd_model)

#Test for Pooled Versus LSDV
pFtest(lsdv_model, pooled_model)


income_groups <- unique(df$income_group)
income_groups

# Creating unique df for each income group and modelling
high_df <- df[df$income_group == "High income", ]
upper_df <- df[df$income_group == "Upper middle income", ]
lower_df <- df[df$income_group == "Lower middle income", ]
low_df <- df[df$income_group == "Low income", ]

re_model_high <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
                       rural_pop + rural_pop_growth + urban_pop_growth + comp_edu
                     + gdp_capita + edu_expenditure + region ,  
                data = high_df, 
                index = c("country", "time"), 
                model = "random",
                effect = 'twoways')
summary(re_model_high)

re_model_upper <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
                        rural_pop + rural_pop_growth + urban_pop_growth + comp_edu
                      + gdp_capita + edu_expenditure + region,  
                     data = upper_df, 
                     index = c("country", "time"), 
                     model = "random",
                     effect = 'twoways')
summary(re_model_upper)

re_model_lower <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
                        rural_pop + rural_pop_growth + urban_pop_growth + comp_edu
                      + gdp_capita + edu_expenditure + region,  
                      data = lower_df, 
                      index = c("country", "time"), 
                      model = "random",
                      effect = 'twoways')
summary(re_model_lower)

re_model_low <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
                      rural_pop + rural_pop_growth + urban_pop_growth + comp_edu
                    + gdp_capita + edu_expenditure + region, 
                      data = low_df, 
                      index = c("country", "time"), 
                      model = "random",
                      effect = 'twoways')
summary(re_model_low)


regions <- unique(df$region)
regions

eurasia_df <- df[df$region == "Europe & Central Asia", ]
middleeast_df <- df[df$region == "Middle East & North Africa", ]
africa_df <- df[df$region == "Sub-Saharan Africa", ]
sa_df <- df[df$region == "Latin America & Caribbean", ]
eastasia_df <- df[df$region == "East Asia & Pacific", ]
southasia_df <- df[df$region == "South Asia", ]
na_df <- df[df$region == "North America", ]


re_eurasia <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
                  rural_pop + rural_pop_growth + urban_pop_growth + comp_edu
                + gdp_capita + income_group, 
                data = eurasia_df, 
                index = c("country", "time"), 
                model = "random",
                effect = 'twoways')

summary(re_eurasia)

re_middleeast <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
                    rural_pop + rural_pop_growth + urban_pop_growth + comp_edu
                  + gdp_capita + income_group, 
                  data = middleeast_df, 
                  index = c("country", "time"), 
                  model = "random",
                  effect = 'twoways')

summary(re_middleeast)


re_africa <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
                       rural_pop + rural_pop_growth + urban_pop_growth + comp_edu
                     + gdp_capita + income_group, 
                     data = africa_df, 
                     index = c("country", "time"), 
                     model = "random",
                     effect = 'twoways')

summary(re_africa)

re_sa <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
                   rural_pop + rural_pop_growth + urban_pop_growth + comp_edu
                 + gdp_capita + income_group, 
                 data = sa_df, 
                 index = c("country", "time"), 
                 model = "random",
                 effect = 'twoways')

summary(re_sa)

re_east <- plm(unemployment ~ gross_fixed_capital_formation + gdp_growth + 
               rural_pop + rural_pop_growth + urban_pop_growth + comp_edu
             + gdp_capita + income_group, 
             data = eastasia_df, 
             index = c("country", "time"), 
             model = "random",
             effect = 'twoways')

summary(re_east)
